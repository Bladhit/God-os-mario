<?php 
    include "../adm/conexao.php";
    include "../adm/controle.php";

    $sql = "select * from aluno order by id";
    $seleciona = mysqli_query($conexao,$sql);
''
?>


        <div class="text-end">
          <a href="aluno.php"> 
            <button type="button" class="btn btn-success btn-sm"> NOVO ALUNO </button>
          </a>
        </div>
        <!-- *******************************************************  Lista de usuários -->
        <h1 class="text-center">Lista de alunos </h1>
        <!-- ********************************************************** Linha de Cabeçalho -->
          <div class="row text-center bg-dark text-light p-2">
              <div class="col-1"> id </div>
              <div class="col-2"> Nome </div>
              <div class="col-2"> Telefone </div>
              <div class="col-3"> email </div>
              <div class="col-2"> turma </div>
             
              <div class="col-2"> Controles </div>
          </div>

    
      
        <!-- ********************************************************** Lista de produtos no BD  -->

                <?php 
                    while ($exibe = mysqli_fetch_array($seleciona)){
                    $id = $exibe['id'];
                ?>

            <div class="row text-center p-2">
            <div class="col-1"> <?php echo $exibe['id'] ?> </div>
              <div class="col-2"> <?php echo $exibe['nome'] ?> </div>
              <div class="col-2"> <?php echo $exibe['telefone'] ?> </div>
              <div class="col-3"> <?php echo $exibe['email'] ?> </div>
              <div class="col-2"> <?php echo $exibe['turma'] ?> </div>
             
              
                <div class="col-2">
                  <a href="visualizar_aluno.php?id=<?php echo $id?>"><span class="material-symbols-outlined">visibility</span></a>

                  <a href="alterar_aluno.php?id=<?php echo $id?>"><span class="material-symbols-outlined"> edit </span></a>

                  <a href="excluir_aluno.php?id=<?php echo $id?>" onclick="return confirm('confirma a exclusão do usuário?')" ><span class="material-symbols-outlined"> delete </span></a>

                </div>

            </div>
                    
            <?php 
       }
     ?>
   <?php 
    include "../adm/rodape.php";
   ?>