<?php

    include "../adm/conexao.php";

    if(isset($_POST['id'])){
        //entrada de dados - recebendo dados do formulario
        $id = trim($_POST['id']);
        $nome = trim($_POST['nome']);
        $telefone = trim($_POST['telefone']);
        $email = trim($_POST['email']);
        $turma = trim($_POST['turma']);
        //processamento - incluir no banco de dados
        $sql= "
            update aluno set nome = '$nome', telefone = '$telefone', email = '$email', turma = '$turma'  where id = '$id' ;
        ";
        $alterar = mysqli_query($conexao,$sql);
    
        //saida - feedback do usuario
        if($alterar){
            echo"
                <script>
                    alert('aluno atualizado com sucesso');
                    window.location = 'listar_aluno.php';
                
                </script>
            
            ";

        }
        else{
            echo"
            <p>Sistema temporariamente fora do ar. Tente novamente mais tarde</p>
            <p>Entre em contato com o administrador do site</p>
            
            ";
            echo mysqli_query($conexao);



        }
    
    
    }

?>