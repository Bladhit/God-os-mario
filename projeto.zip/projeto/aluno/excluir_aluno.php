<?php 
    include "../adm/conexao.php";

    if(isset($_GET['id'])){
        //entrada de dados
        $id = $_GET['id'];

        //processamento escreve e executa a sql

        $sql = "delete from aluno where id = '$id' ";
        $excluir = mysqli_query($conexao,$sql); 

        //saida da o feedback do usuario
        if($excluir){
            echo "
                <script> 
                    alert('aluno excluido com sucesso!');
                    window.location = 'listar_aluno.php';
                 </script>
            ";
            // redirecionador de pagina do php abaixo;
            //header("location listar_usuario.php");
        }

        else{
            echo"
            <p>Banco de dados temporariamente fora do ar. Tente novamente mais tarde.</p>
            <p>entre em contato com o administrador do site...</p>
            ";

            echo mysqli_error($conexao);

        }
    }


?>