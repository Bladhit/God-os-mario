<?
    include "../adm/controle.php";
?>
        <h1 class='text-center'>Cadastro de aluno </h1>
        <hr>
        <form name="cadastro" method="post" action="cadastrar_aluno.php">
            <div class="mb-3">
                <label for="nome" class="form-label">nome</label>
                <input type="text" class="form-control" id="nome" name="nome" placeholder="Nome" required>
            </div>  
            <div class="mb-3">
                <label for="telefone" class="form-label">telefone</label>
                <input type="text" class="form-control" id="telefone" name="telefone" placeholder="telefone" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">email</label>
                <input type="text" class="form-control" id="email" name="email" placeholder="email" required>
            </div>
            <div class="mb-3">
                <label for="turma" class="form-label">turma</label>
                <input type="text" class="form-control" id="turma" name="turma" placeholder="turma (numeros 1.2.3...)" required>
            </div>
            
            <div class="text-end">
                <button type="reset" class="btn btn-secondary">Limpar</button>
                <button type="submit" class="btn btn-primary">Cadastrar</button>
            </div>


        </form>
    
        <? 
            include "../adm/rodape.php";
        ?>