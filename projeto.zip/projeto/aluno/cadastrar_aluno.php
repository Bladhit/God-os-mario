<?php 

    include "../adm/conexao.php";
    
    if(isset($_POST['nome'])){
        //coletar dados do formulário ()
        $nome = trim($_POST['nome']);
        $telefone = trim($_POST['telefone']);
        $email = trim($_POST['email']);
        $turma = trim($_POST['turma']);
       

        //inserir no banco de dados
        $sql = "insert into aluno(nome,telefone,email,turma) values ('$nome','$telefone','$email','$turma')";
        $incluir = mysqli_query($conexao,$sql);

        //saida - feedback ao usuário
        if($incluir){
        echo"
            <script>
                alert('aluno cadastrado com sucesso!');
                window.location = 'listar_aluno.php';
            </script>
        ";
        }else{ //tratamento de erro
            echo "<p>banco de dados temporariamente fora do ar. Entre em contato com o administrador do site para reportar o problema</p>";
            echo "<p>Clique <a href='aluno.php'>aqui<a> para acessar o 
                 formulário de cadastro.</p>";
        }

    }else{ //tratamento de erro

        echo "<p>Está é uma página de tratamento de dados</p>";
        echo "<p>Clique <a href='aluno.php'>aqui<a> para acessar o 
        formulário de cadastro.</p>";
    }

?>