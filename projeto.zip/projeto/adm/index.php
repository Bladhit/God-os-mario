<?php 

include "seguranca.php"; 

?>

<center>
<h1>Pagina inicial dos alunos da acadmia</h1>
</center>


