<?php 
    session_start(); //inicia a seção
    $_SESSION = array();
    session_destroy();
    header('location:../academia/index.php'); //redireciona para a area de login

?>