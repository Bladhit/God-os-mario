
    <!DOCTYPE html>
<html lang="pt-br">

<head>

  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Fisio Life</title>
  <meta content="" name="keywords">
  <meta content="" name="description">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="../css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    

  <link href="https://fonts.googleapis.com/css?family=Poppins:300,300i,400,400i,500,500i,600,600i,700,700i|Playfair+Display:400,400i,700,700i,900,900i" rel="stylesheet">

  <link href="../academia/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <link href="../academia/lib/ionicons/css/ionicons.min.css" rel="stylesheet">
  <link href="../academia/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="../academia/lib/magnific-popup/magnific-popup.css" rel="stylesheet">
  <link href="../academia/lib/hover/hover.min.css" rel="stylesheet">

  <link href="../academia/css/style.css" rel="stylesheet">

  <link href="../academia/css/responsive.css" rel="stylesheet">

  <link rel="shortcut icon" href="../academia/images/logo.png">
   <link rel="stylesheet" href="../css/login.css">


</head>

<body>

  <nav id="main-nav">
    <div class="row">
      <div class="container">

        <div class="logo">
          <a href="index.php"><img src="../academia/images/logo.png" alt="logo"></a>
        </div>

        <div class="responsive"><i data-icon="m" class="ion-navicon-round"></i></div>

        <ul class="nav-menu list-unstyled">
          <li><a href="../academia/index.php" class="smoothScroll">Voltar para o site</a></li>
          <li><a href="../adm/login.php" class="smoothScroll">Login</a></li>
        </ul>

      </div>
    </div>
  </nav>
  <br>
  <div class="login container-fluid text-dark p-3">
   <h1 id="fundo-x" class="text-center "> Área de Login </h1>
    <hr>


    <center><h1 class="mt-5"> Logar-se</h1></center>
    <p class="text-center">Se ja possui cadastro logue-se</p>
    
    <div class="row">
        <form name="form" class="mt-5" method="post" action="valida.php">
            <div class="mb-3">
                <label for="login" class="form-label" name="login" required> Login </label>
                <input type="text" class="form-control" id="login" name="login" required>   
            </div>
            <div class="mb-3">
                <label for="senha" class="form-label" name="senha" required> Senha </label>
                <input type="password" class="form-control" id="senha" name="senha" required>   
            </div>  
                <div class="text-end">
                <button type="reset" class="btn btn-secondary">Limpar</button>
                <button type="submit" class="btn btn-primary "> ok </button>
                </div>             
            
        </form >

        <div class="mt-5 text-danger text-center">
            <?php
                include "valida.php";
            
            
            ?>
        </div>
    </div>

           
    <!--xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx !-->

        <h1 class="text-center mt-5" id="cadastro">Não possui cadastro?</h1>
        <p class="text-center">cadastre-se abaixo:</p>
        <hr>

       
        <form name="cadastro" method="post" action="../usuario/cadastar_usuarios.php">
        <div class="mb-3">
        <div class="mb-3">
        <label for="nome" class="form-label">Nome</label>
        <input type="text" class="form-control" id="nome" name="nome" placeholder="Nome Completo" rows="3" required> 
        </div>
        <label for="exampleFormControlInput1" class="form-label">Login</label>
        <input type="text" class="form-control" id="login" name="login" placeholder="Login (obrigatorio)">
        </div>
        <div class="mb-3">
        <label for="senha" class="form-label">Senha</label>
        <input type="password" class="form-control" id="senha" name="senha" placeholder="******" rows="3" required> 
        </div>
        <div class="mb-3">
        <label for="email" class="form-label">Email</label>
        <input type="email" class="form-control" id="email" name="email" placeholder="email@provedor.com" rows="3" required> 
        </div>
        <hr clas="mt-5 mb-4">
    <div class="text-end">
        <button type="reset" class="btn btn-secondary">Limpar</button>
        <button type="submit" class="btn btn-primary">Cadastrar</button>
    </div>   


        </form>
  
  
    </div>


    <!--xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx !-->
    
    

  <div id="footer" class="text-center">
    <div class="container">
      <div class="socials-media text-center">

        <ul class="list-unstyled">
          <li><a href="#"><i class="ion-social-facebook"></i></a></li>
          <li><a href="#"><i class="ion-social-twitter"></i></a></li>
          <li><a href="#"><i class="ion-social-instagram"></i></a></li>
          <li><a href="#"><i class="ion-social-googleplus"></i></a></li>
          <li><a href="#"><i class="ion-social-tumblr"></i></a></li>
          <li><a href="#"><i class="ion-social-dribbble"></i></a></li>
        </ul>

      </div>

      <p>&copy; Copyrights Folio. All rights reserved.</p>

     
    </div>
  </div>

  <script src="../academia/lib/jquery/jquery.min.js"></script>
  <script src="../academia/lib/jquery/jquery-migrate.min.js"></script>
  <script src="../academia/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../academia/lib/typed/typed.js"></script>
  <script src="../academia/lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="../academia/lib/magnific-popup/magnific-popup.min.js"></script>
  <script src="../academia/lib/isotope/isotope.pkgd.min.js"></script>


  <script src="../academia/contactform/contactform.js"></script>


  <script src="../academia/js/main.js"></script>

</body>

</html>
