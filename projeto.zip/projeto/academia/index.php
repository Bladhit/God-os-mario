<!DOCTYPE html>
<html lang="pt-br">

<head>

  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Fisio Life</title>
  <meta content="" name="keywords">
  <meta content="" name="description">

  <link href="https://fonts.googleapis.com/css?family=Poppins:300,300i,400,400i,500,500i,600,600i,700,700i|Playfair+Display:400,400i,700,700i,900,900i" rel="stylesheet">

  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">
  <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="lib/magnific-popup/magnific-popup.css" rel="stylesheet">
  <link href="lib/hover/hover.min.css" rel="stylesheet">

  <link href="css/style.css" rel="stylesheet">

  <link href="css/responsive.css" rel="stylesheet">

  <link rel="shortcut icon" href="images/logo.png">
  <link rel="stylesheet" href="../academia/css/loged.css">


</head>

<body>

  <nav id="main-nav">
    <div class="row">
      <div class="container">

        <div class="logo">
          <a href="index.php"><img src="images/logo.png" alt="logo"></a>
        </div>

        <div class="responsive"><i data-icon="m" class="ion-navicon-round"></i></div>

        <ul class="nav-menu list-unstyled">
          <li><a href="#header" class="smoothScroll">Home</a></li>
          <li><a href="#about" class="smoothScroll">Sobre</a></li>
          <li><a href="#portfolio" class="smoothScroll">Portfolio</a></li>
          <li><a href="#journal" class="smoothScroll">Blog</a></li>
          <li><a href="#contact" class="smoothScroll">Contatar</a></li>
          <li><a href="../adm/index.php" class="smoothScroll">Area do Aluno</a></li>
          </ul>
          </div>
    </div>

          <hr>
           <div class="text-center">

          <?php 
                  if(!isset($_SESSION)){
                      session_start(); //iniciando a sessão
                  }
                
                  if(isset($_SESSION['login'])){

                    $login = $_SESSION['login'];
                    $nome = $_SESSION['nome'];
                    $nivel = $_SESSION['nivel'];

                    echo"Bem Vindo : $nome | ";
                    
                    if($nivel == "adm"){
                      echo"<a href='../adm/adm.php'> administração | </a> ";
                    }
                    echo "<a href='../adm/logout.php'>Logout </a>";

                } else{
                  
                ?>  
                    <li>
                    <a href="../adm/login.php" class="">
                    LOGIN |
                    </a>
                    
                    
                    <a href="../adm/login.php#cadastro" class="">
                     NÃO POSSUO CADASTRO
                    </a>
                    

                    <?php } ?>
                </div>


</nav>              
        


  <div id="header" class="home">

    <div class="container">
      <div class="header-content">
        <h1>Venha <span class="typed"></span></h1>
        <p>Foco, Força, Fé</p>

        <ul class="list-unstyled list-social">
          <li><a href="#"><i class="ion-social-facebook"></i></a></li>
          <li><a href="#"><i class="ion-social-twitter"></i></a></li>
          <li><a href="#"><i class="ion-social-instagram"></i></a></li>
          <li><a href="#"><i class="ion-social-googleplus"></i></a></li>
          <li><a href="#"><i class="ion-social-tumblr"></i></a></li>
          <li><a href="#"><i class="ion-social-dribbble"></i></a></li>
        </ul>
      </div>
    </div>
  </div>

  <div id="about" class="paddsection">
    <div class="container">
      <div class="row justify-content-between">

        <div class="col-lg-4 ">
          <div class="div-img-bg">
            <div class="about-img">
              <img src="images/me.jpg" class="img-responsive" alt="me">
            </div>
          </div>
        </div>

        <div class="col-lg-7">
          <div class="about-descr">

            <p class="p-heading">Você tem três escolhas na vida: desistir, ceder ou dar o melhor de si.</p>
            <p class="separator">Ir à academia não é brincadeira, é saúde! Venha cuidar da sua saúde, melhorar sua qualidade de vida e aproveitar cada momento com quem você ama. Aqui na Fisio Life temos os melhores programas e condições especiais para você!</p>

          </div>

        </div>
      </div>
    </div>
  </div>

  <div id="services">
    <div class="container">

        <div class="services-carousel owl-theme">

          <div class="services-block">

            <i class="ion-ios-browsers-outline"></i>
            <span>Musculação</span>
            <p class="separator">Apesar dos treinos intermináveis que algumas academias receitam, aqui fazemos o treino certo para você</p>

          </div>

          <div class="services-block">

            <i class="ion-ios-lightbulb-outline"></i>
            <span>Treino funcional</span>
            <p class="separator">O corpo todo trabalha ao mesmo tempo. Com isso, não se vê a necessidade de um treino muito extenso</p>

          </div>

          <div class="services-block">

            <i class="ion-ios-color-wand-outline"></i>
            <span>Corrida</span>
            <p class="separator">Seja indoor ou outdoor, a corrida combina com vários ambientes, o que proporciona um resultado sensacional, ainda mais pensando na melhora da capacidade respiratória</p>

          </div>

          <div class="services-block">

            <i class="ion-social-android-outline"></i>
            <span>Spinning</span>
            <p class="separator">Essa aula é ótima para quem não gosta muito de correr e prefere modalidades mais dinâmicas.</p>

          </div>

          <div class="services-block">

            <i class="ion-ios-analytics-outline"></i>
            <span>Bike outdoor</span>
            <p class="separator">Essa é uma ótima alternativa para quem busca uma rotina diária com um exercício cardio forte, mas não consegue ou não gosta de correr. </p>

          </div>

          <div class="services-block">

            <i class="ion-ios-camera-outline"></i>
            <span>Dança</span>
            <p class="separator">Seria uma ótima alternativa para quem quer um exercício intenso e rápido, além de trazer uma alegria excepcional para o praticante</p>

          </div>

        </div>

    </div>

  </div>

  <div id="portfolio" class="text-center paddsection">

    <div class="container">
      <div class="section-title text-center">
        <h2>Programações</h2>
      </div>
    </div>

    <div class="container">
      <div class="row">
        <div class="col-md-12">

          <div class="portfolio-list">

            <ul class="nav list-unstyled" id="portfolio-flters">
              <li class="filter filter-active" data-filter=".all">Todos</li>
              <li class="filter" data-filter=".branding">Musculação</li>
              <li class="filter" data-filter=".mockups">Dança</li>
              <li class="filter" data-filter=".uikits">Nutricionista</li>
              <li class="filter" data-filter=".webdesign">CrossFit</li>
              <li class="filter" data-filter=".photography">Muya thai</li>
            </ul>

          </div>

          <div class="portfolio-container">

            <div class="col-lg-4 col-md-6 portfolio-thumbnail all branding uikits webdesign">
              <a class="popup-img" href="images/portfolio/1.jpg">
                <img src="images/portfolio/1.jpg" alt="img">
              </a>
            </div>

            <div class="col-lg-4 col-md-6 portfolio-thumbnail all mockups uikits photography">
              <a class="popup-img" href="images/portfolio/2.jpg">
                <img src="images/portfolio/2.jpg"  alt="img">
              </a>
            </div>

            <div class="col-lg-4 col-md-6 portfolio-thumbnail all branding webdesig photographyn">
              <a class="popup-img" href="images/portfolio/3.jpg">
                <img src="images/portfolio/3.jpg" alt="img">
              </a>
            </div>

            <div class="col-lg-4 col-md-6 portfolio-thumbnail all mockups webdesign photography">
              <a class="popup-img" href="images/portfolio/4.jpg">
                <img src="images/portfolio/4.jpg" alt="img">
              </a>
            </div>

            <div class="col-lg-4 col-md-6 portfolio-thumbnail all branding uikits photography">
              <a class="popup-img" href="images/portfolio/5.jpg">
                <img src="images/portfolio/5.jpg" alt="img">
              </a>
            </div>

            <div class="col-lg-4 col-md-6 portfolio-thumbnail all mockups uikits webdesign">
              <a class="popup-img" href="images/portfolio/6.jpg">
                <img src="images/portfolio/6.jpg" alt="img">
              </a>
            </div>

          </div>
        </div>
      </div>
    </div>

  </div>

  <div id="journal" class="text-left paddsection">

    <div class="container">
      <div class="section-title text-center">
        <h2>Sobre</h2>
      </div>
    </div>

    <div class="container">
      <div class="journal-block">
        <div class="row">

          <div class="col-lg-4 col-md-6">
            <div class="journal-info">

              <a href="blog-single.php"><img src="images/blog-post-1.jpg" class="img-responsive" alt="img"></a>

              <div class="journal-txt">

                <h4><a href="blog-single.php">SO LETS MAKE THE MOST IS BEAUTIFUL</a></h4>
                <p class="separator">To an English person, it will seem like simplified English
                </p>

              </div>

            </div>
          </div>

          <div class="col-lg-4 col-md-6">
            <div class="journal-info">

              <a href="blog-single2.php"><img src="images/blog-post-2.jpg" class="img-responsive" alt="img"></a>

              <div class="journal-txt">

                <h4><a href="#blog-single2.php">WE'RE GONA MAKE DREAMS COMES</a></h4>
                <p class="separator">To an English person, it will seem like simplified English
                </p>

              </div>

            </div>
          </div>

          <div class="col-lg-4 col-md-6">
            <div class="journal-info">

              <a href="blog-single3.php"><img src="images/blog-post-3.jpg" class="img-responsive" alt="img"></a>

              <div class="journal-txt">

                <h4><a href="blog-single3.php">NEW LIFE CIVILIZATIONS TO BOLDLY</a></h4>
                <p class="separator">To an English person, it will seem like simplified English
                </p>

              </div>

            </div>
          </div>

        </div>
      </div>
    </div>

  </div>

  <div id="contact" class="paddsection">
    <div class="container">
      <div class="contact-block1">
        <div class="row">

          <div class="col-lg-6">
            <div class="contact-contact">

              <h2 class="mb-30">Informações</h2>

              <ul class="contact-details">
                <li><span> <a href="https://www.google.com/maps/place/R.+Japoara,+246+-+Ricardo+de+Albuquerque,+Rio+de+Janeiro+-+RJ,+21620-390/@-22.839346,-43.4036337,17z/data=!3m1!4b1!4m6!3m5!1s0x9963da18dfa291:0xa4d3e2d350900ae6!8m2!3d-22.839346!4d-43.401445!16s%2Fg%2F11c4fqsvfn">R. Japoara, 246 - Ricardo de Albuquerque</a></span></li>
                <li><span> <a href="https://wa.me/5521985251041">21 985251041</a> </span></li>
                <li><span> <a href="mailto:contact@domain.com? Subject:">academiafisioliferj@gmail.com</a> </span></li>
              </ul>

            </div>
          </div>

          <div class="col-lg-6">
            <form action="" method="post" role="form" class="contactForm">
              <div class="row">

                <div id="sendmessage">Sua mensagem foi enviada. Obrigado!</div>
                <div id="errormessage"></div>

                <div class="col-lg-6">
                  <div class="form-group contact-block1">
                    <input type="text" name="name" class="form-control" id="name" placeholder="Seu nome" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                    <div class="validation"></div>
                  </div>
                </div>

                <div class="col-lg-6">
                  <div class="form-group">
                    <input type="email" class="form-control" name="email" id="email" placeholder="Seu Email" data-rule="email" data-msg="Please enter a valid email" />
                    <div class="validation"></div>
                  </div>
                </div>

                <div class="col-lg-12">
                  <div class="form-group">
                    <input type="text" class="form-control" name="subject" id="subject" placeholder="Assunto" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" />
                    <div class="validation"></div>
                  </div>
                </div>

                <div class="col-lg-12">
                  <div class="form-group">
                    <textarea class="form-control" name="message" rows="12" data-rule="required" data-msg="Please write something for us" placeholder="Mensagem"></textarea>
                    <div class="validation"></div>
                  </div>
                </div>

                <div class="col-lg-12">
                  <input type="submit" class="btn btn-defeault btn-send" value="Enviar Mensagem">
                </div>

              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div id="login" class="paddsection">
    <div class="container">
      <div class="contact-block1">

        <!--Login-->

      </div>
    </div>
  </div>

  <div id="footer" class="text-center">
    <div class="container">
      <div class="socials-media text-center">

        <ul class="list-unstyled">
          <li><a href="#"><i class="ion-social-facebook"></i></a></li>
          <li><a href="#"><i class="ion-social-twitter"></i></a></li>
          <li><a href="#"><i class="ion-social-instagram"></i></a></li>
          <li><a href="#"><i class="ion-social-googleplus"></i></a></li>
          <li><a href="#"><i class="ion-social-tumblr"></i></a></li>
          <li><a href="#"><i class="ion-social-dribbble"></i></a></li>
        </ul>

      </div>

      <p>&copy; Copyrights Folio. All rights reserved.</p>

      <div class="credits">
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
      </div>

    </div>
  </div>

  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/typed/typed.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/magnific-popup/magnific-popup.min.js"></script>
  <script src="lib/isotope/isotope.pkgd.min.js"></script>


  <script src="contactform/contactform.js"></script>


  <script src="js/main.js"></script>

</body>

</html>
