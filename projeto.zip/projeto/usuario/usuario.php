<?php
   include "../adm/controle.php"
?>

        <h1 class="text-center">Cadastro de usuário</h1>
        <hr>

       
        <form name="cadastro" method="post" action="cadastar_usuarios.php">
        <div class="mb-3">
        <div class="mb-3">
        <label for="nome" class="form-label">Nome</label>
        <input type="text" class="form-control" id="nome" name="nome" placeholder="Nome Completo" rows="3" required> 
        </div>
        <label for="exampleFormControlInput1" class="form-label">Login</label>
        <input type="text" class="form-control" id="login" name="login" placeholder="Login required">
        </div>
        <div class="mb-3">
        <label for="senha" class="form-label">Senha</label>
        <input type="password" class="form-control" id="senha" name="senha" placeholder="******" rows="3" required> 
        </div>
        <div class="mb-3">
        <label for="email" class="form-label">Email</label>
        <input type="email" class="form-control" id="email" name="email" placeholder="email@provedor.com" rows="3" required> 
        </div>
        <hr clas="mt-5 mb-4">
    <div class="text-end">
        <button type="reset" class="btn btn-secondary">Limpar</button>
        <button type="submit" class="btn btn-primary">Cadastrar</button>
    </div>   


        </form>
  
  
    </div>








<?php
  include "../adm/rodape.php";
?>