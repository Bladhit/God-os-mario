<?php

    include "../adm/conexao.php";
    include "../adm/controle.php";
    include "../adm/seguranca.php";

    if(isset($_GET['login'])){
        $login = $_GET['login'];

        $sql= "select * from usuario where login = '$login' ";
        $seleciona = mysqli_query($conexao,$sql);
        $exibe = mysqli_fetch_array($seleciona);
    
        $nome = $exibe['nome'];
        $senha = $exibe['senha'];
        $email = $exibe['email'];
    
    
?>


    <div class="container bg-info p-3 mt-5">
        <div class="text-end">
            <a href="listar_usuario.php">
                <button class="btn btn-success btn-sm">Listar usuario</button>
            </a>        
        </div>

        <h2>Usuario: <?php echo $nome ?> </h2>
        <hr>
        <div class="container text-start bg-gradient p-3">
            <?php 
                echo"

            <p>Login: $login</p>
            <p>Senha: ******</p>
            <p>Email: $email</p>

            "
            ?>
        </div> 

        <div class="row">

            <div class="col text-start">
                <a href='listar_usuario.php'>
                <button class="btn btn-warning btn-sm">Voltar</button>
                </a>
         </div>
         

            <div class="col text-center">
                <a href='alterar_senha.php'>
                <button class="btn btn-warning btn-sm">Alterar senha</button>
                </a>
            </div>



         <div class="col text-end">   

             <a href="alterar_usuario.php?login=<?php echo $login ?>"> 
            <button class="btn btn-primary btn-sm">Editar Dados</button>
             </a>

         </div>   

        </div>

    </div>

<?php 
    }
    else{
       echo"
       <p> esta é uma pagina de tratamento de dados. </p>
       <p>Clique <a href='listar_usuario.php'>aqui</a> para seleionar o usuario que deseja visualizar.</p>
       ";
    }

    include "../adm/rodape.php";

?>