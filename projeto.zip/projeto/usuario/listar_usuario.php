<?php 
    include "../adm/conexao.php";
    include "../adm/controle.php";
    include "../adm/seguranca_adm.php";

    $sql = "select * from usuario order by nome";
    $seleciona = mysqli_query($conexao,$sql);
''
?>


          <h1 class="text-center">Listar usuarios</h1>
          
          <div class="text-end">
            <a href="usuario.php">
                <button type="button" class="btn btn-success btn-sm mb-3 ">NOVO USUARIO</button>
            </a>
            
            <div class="row text-center bg-dark text-light p-2">
                <div class="col-2"> Nome</div>        
                <div class="col-2"> Login  </div>        
                <div class="col-2"> Senha </div>        
                <div class="col-2"> E-mail </div>        
                <div class="col-2"> Nivel  </div>        
                <div class="col-2"> Controles </div>        
            </div>
    </div>   

            <?php 
                while ($exibe = mysqli_fetch_array($seleciona)){
                    $login = $exibe['login'];
            ?>

             <div class="row text-center p-1">
                <div class="col-2"> <?php echo $exibe['nome']?></div>        
                <div class="col-2"> <?php echo $exibe['login'] ?> </div>        
                <div class="col-2"> *** </div>        
                <div class="col-2"> <?php echo $exibe['email'] ?> </div>        
                <div class="col-2"> <?php echo $exibe['nivel'] ?> </div>        
                <div class="col-2"> 
                    
                <a href="alterar_usuario.php?login=<?php echo $login?>">     
                <span class="material-symbols-outlined"> edit</span> </a>

                <a href="visualizar_usuario.php?login=<?php echo $login?>">
                <span class="material-symbols-outlined">visibility</span>   </a>

                <a href="excluir_usuario.php?login=<?php echo $login?>" onclick="return confirm('confirma a exclusão do usuário?')">
                <span class="material-symbols-outlined">delete</span> </a> 

            </div>        
        </div>  
    <?php 
       }
     ?>


<?php
include "../adm/rodape.php";
?>