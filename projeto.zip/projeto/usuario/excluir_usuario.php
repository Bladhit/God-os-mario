<?php 
    include "../adm/conexao.php";
    include "../adm/seguranca_adm.php";

    if(isset($_GET['login'])){
        //entrada de dados
        $login = $_GET['login'];

        //processamento escreve e executa a sql

        $sql = "delete from usuario where login = '$login' ";
        $excluir = mysqli_query($conexao,$sql); 

        //saida da o feedback do usuario
        if($excluir){
            echo "
                <script> 
                    alert('Usuario excluido com sucesso!');
                    window.location = 'listar_usuario.php';
                 </script>
            ";
            // redirecionador de pagina do php abaixo;
            //header("location listar_usuario.php");
        }

        else{
            echo"
            <p>Banco de dados temporariamente fora do ar. Tente novamente mais tarde.</p>
            <p>entre em contato com o administrador do site...</p>
            ";

            echo mysqli_error($conexao);

        }
    }


?>