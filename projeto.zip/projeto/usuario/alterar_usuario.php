<?php

    include "../adm/conexao.php";
    include "../adm/controle.php";
    include "../adm/seguranca.php";

    if(isset($_GET['login'])){
        $login = $_GET['login'];

        $sql= "select * from usuario where login = '$login' ";
        $seleciona = mysqli_query($conexao,$sql);
        $exibe = mysqli_fetch_array($seleciona);
    
        $nome = $exibe['nome'];
        $senha = $exibe['senha'];
        $email = $exibe['email'];
    
    }
?>



        <h1 class="text-center">Editar usuario</h1>
        <hr>

       
        <form name="cadastro" method="post" action="update_usuario.php">
        <div class="mb-3">
      




        <input type="hidden" name="login" value="<?php echo $login?>">
        <div class="mb-3">

        <label for="nome" class="form-label">login</label>
        <input type="text" class="form-control" id="login" name="login" placeholder="Login" value="<?php echo $login?>"rows="3" required disabled> 
        </div>
        <div class="mb-3">

        <label for="nome" class="form-label">Nome</label>
        <input type="text" class="form-control" id="nome" name="nome" placeholder="Nome Completo" value="<?php echo $nome?>"rows="3" required> 
        </div>

      

        <div class="mb-3">
        <label for="email" class="form-label">Email</label>
        <input type="email" class="form-control" id="email" name="email" placeholder="email@provedor.com" value="<?php echo $email?>" rows="3" required> 
        </div>
        <hr clas="mt-5 mb-4">
    <div class="text-end">
        <button type="button" class="btn btn-secondary">Voltar</button>
        <button type="submit" class="btn btn-primary" onclick="return confirm('confirma fazer a alteração do usuário?')">Alterar</button>
    </div>   


        </form>
  
  
<?php 
include "../adm/rodape.php";
?>